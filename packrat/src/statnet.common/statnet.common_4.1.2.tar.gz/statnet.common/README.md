# `statnet.common`:  Common R Scripts and Utilities Used by the Statnet Project Software

[![Build Status](https://travis-ci.org/statnet/statnet.common.svg?branch=master)](https://travis-ci.org/statnet/statnet.common)
[![Build Status](https://ci.appveyor.com/api/projects/status/28p03h7f78rp95if?svg=true)](https://ci.appveyor.com/project/statnet/statnet-common)
[![rstudio mirror downloads](http://cranlogs.r-pkg.org/badges/statnet.common?color=2ED968)](http://cranlogs.r-pkg.org/)
[![cran version](http://www.r-pkg.org/badges/version/statnet.common)](https://cran.r-project.org/package=statnet.common)
[![Coverage status](https://codecov.io/gh/statnet/statnet.common/branch/master/graph/badge.svg)](https://codecov.io/github/statnet/statnet.common?branch=master)

Non-statistical utilities used by the software developed by the Statnet Project. They may also be of use to others.
