#' @useDynLib GroupAssignment
#' @importFrom Rcpp evalCpp
NULL