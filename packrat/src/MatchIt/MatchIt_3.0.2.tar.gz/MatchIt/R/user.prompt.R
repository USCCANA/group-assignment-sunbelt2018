#' @export
user.prompt <- function() 
  silent <- readline("\nPress <return> to continue: ")
