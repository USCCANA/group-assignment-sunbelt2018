library(testthat)
library(MatchIt)

test_check("MatchIt")
