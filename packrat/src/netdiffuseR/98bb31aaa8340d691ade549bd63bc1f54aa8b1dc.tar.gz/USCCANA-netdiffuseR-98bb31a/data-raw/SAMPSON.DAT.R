file.copy("data-raw/SAMPSON.DAT", "inst/extdata/")
